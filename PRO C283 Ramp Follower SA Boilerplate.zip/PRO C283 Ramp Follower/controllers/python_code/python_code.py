from controller import Robot
from controller import Motor
from controller import Altimeter
from controller import LED
import math



class MyController(Robot):
    def __init__(self):
        super(MyController, self).__init__()
        self.timeStep = 32  # set the control time step

        # get device tags
        # self.distanceSensor = self.getDistanceSensor('my_distance_sensor')
        # self.led = self.getLed('my_led')
        # self.distanceSensor.enable(timeStep)  # enable sensors to read data from them
        
        self.altimeter=self.getDevice("altimeter")
        self.altimeter.enable(self.timeStep)
        
      

    def run(self):
            
        
    
# main Python program
controller = MyController()
controller.run()
